<?php

header("Location: login");
?>