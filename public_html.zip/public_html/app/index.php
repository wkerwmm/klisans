<?php

header("Location: /login");
?>