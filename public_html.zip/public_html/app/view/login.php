<?php
require_once($_SERVER['DOCUMENT_ROOT'] . '/app/system/database/db_connect.php');
session_start();

if(isset($_SESSION["username"])) {
    header("Location: dashboard");
    exit();
}

$stmt = $db->query("SELECT * FROM site_settings");
$site_settings = $stmt->fetch(PDO::FETCH_ASSOC);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if(isset($_POST["username"]) && isset($_POST["password"]) && isset($_POST["customer_code"])) {
        $username = $_POST["username"];
        $password = $_POST["password"];
        $customer_code = $_POST["customer_code"];
        $user_ip = $_SERVER['REMOTE_ADDR']; // Kullanıcının IP adresini al

        // Kullanıcı adı ve şifreyle giriş yap
        $hashed_password = hash('sha256', $password);
        $stmt = $db->prepare("SELECT * FROM users WHERE username = :username AND password = :password");
        $stmt->bindParam(":username", $username);
        $stmt->bindParam(":password", $hashed_password); 
        $stmt->execute();
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user) {
            // Kullanıcı adı ve şifre doğrulandı, müşteri kodunu kontrol et
            $stmt = $db->prepare("SELECT * FROM users WHERE username = :username AND customer_code = :customer_code");
            $stmt->bindParam(":username", $username);
            $stmt->bindParam(":customer_code", $customer_code); 
            $stmt->execute();
            $user_with_code = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($user_with_code) {
                // Müşteri kodu eşleşti, enum durumu kontrol et
                $enum_status = $user_with_code['account_status'];

                if ($enum_status == 'pending') {
                    // Durum 'pending' ise /pending sayfasına yönlendir
                    header("Location: /pending");
                    exit();
                } elseif ($enum_status == 'approved') {
                    // Durum 'approved' ise oturumu başlat ve dashboard'a yönlendir
                    $_SESSION["username"] = $user["username"];
                    header("Location: /dashboard");
                    exit();
                } elseif ($enum_status == 'banned') {
                    // Durum 'banned' ise /banned sayfasına yönlendir
                    header("Location: /banned");
                    exit();
                }
            } else {
                // Müşteri kodu eşleşmedi, hata mesajı ver
                $error_message = "Müşteri kodu yanlış.";
            }
        } else {
            // Kullanıcı adı veya şifre yanlış, hata mesajı ver
            $error_message = "Kullanıcı adı veya şifre yanlış.";
        }

        // Başarısız giriş, log tut
        $log_message = "Hesabınıza izinsiz giriş yapılıyor, giriş yapmaya çalıştığı bilgiler: $username, Müşteri Kodu: $customer_code from İP: $user_ip";
        // Logu veritabanına ekle
        $stmt = $db->prepare("INSERT INTO login_logs (username, customer_code, ip_address, log_message) VALUES (:username, :customer_code, :ip_address, :log_message)");
        $stmt->bindParam(":username", $username);
        $stmt->bindParam(":customer_code", $customer_code);
        $stmt->bindParam(":ip_address", $user_ip);
        $stmt->bindParam(":log_message", $log_message);
        $stmt->execute();
    } else {
        // POST verisi eksik, hata mesajı ver
        $error_message = "Kullanıcı adı, şifre veya müşteri kodu eksik.";
    }
}
if ($user['role'] == 'admin') {
    // Kullanıcı admin ise, authorized_code sütununu güncelle
    $stmt = $db->prepare("UPDATE users SET authorized_code = :customer_code WHERE username = :username");
    $stmt->bindParam(":customer_code", $customer_code);
    $stmt->bindParam(":username", $username);
    $stmt->execute();
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../assest/css/pages/login.css"> 
    <title><?php echo $site_settings['site_name']; ?> - Giriş Yap</title>
</head>
<body>
    <div class="container">
        <h2><?php echo $site_settings['site_name']; ?></h2>
        <form id="loginForm" method="post">
            <p>Bu sayfaya sadece kullanıcılar erişebilir.</p>
            <label for="customer_code">Müşteri Kodu:</label>
            <input type="text" id="customer_code" name="customer_code" placeholder="Müşteri Kodu(Müşteri Girişi)">
            
            <label for="username">Kullanıcı Adı:</label>
            <input type="text" id="username" name="username" placeholder="Kullanıcı Adı" required>
            
            <label for="password">Şifre:</label>
            <input type="password" id="password" name="password" placeholder="Şifre" required>

            <input type="submit" id="loginButton" value="Giriş Yap">
            <p>Eğer kayıtlı değilseniz, <a href="register" style="text-decoration: none;">buraya</a> basınız</p>
        </form>
        <?php 
        if(isset($error_message)) { 
            echo '<p class="error-message">' . $error_message . '</p>';
        } 
        ?>
    </div>

</body>
</html>
