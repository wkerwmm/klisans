<?php
require_once($_SERVER['DOCUMENT_ROOT'] . '/app/system/database/db_connect.php');
//require_once($_SERVER['DOCUMENT_ROOT'] . '/app/helpers/web_management.php');
//require_once($_SERVER['DOCUMENT_ROOT'] . '/app/helpers/punishment_management.php');
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login");
    exit();
}
?>

