<?php
// Lisansın geçerli olup olmadığını kontrol etmek için bir değişken
$validLicense = false;

// Lisans doğrulama sunucusunun URL'si
$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";

// Mevcut sayfanın ana hostunu al
$host = $_SERVER['HTTP_HOST'];

// Lisans doğrulama sunucusunun URL'sini oluştur
$verificationURL = "$protocol://$host/licence/verification";

// Gelen IP adresini al
$clientIP = $_SERVER['REMOTE_ADDR'];

// Lisansın geçerliliğini kontrol eden fonksiyon
function checkLicenseValidity($verificationURL, $clientIP) {
    // CURL ile HTTP isteği gönderme
    $ch = curl_init();
    if (!$ch) {
        die("CURL başlatılamadı.");
    }
    curl_setopt($ch, CURLOPT_URL, $verificationURL);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query(array('ip_address' => $clientIP)));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $response = curl_exec($ch);
    if ($response === false) {
        die("CURL hatası: " . curl_error($ch));
    }

    curl_close($ch);

    // Sunucudan gelen yanıtı kontrol etme
    if ($response === "valid") {
        // Lisans geçerliyse true döndür
        return true;
    } else {
        // Lisans geçersizse false döndür
        return false;
    }
}

// Eğer daha önce lisansı kontrol ettik ve geçerli ise, tekrar kontrol etmeyiz
if(!$validLicense) {
    // Lisansın geçerliliğini kontrol et
    $validLicense = checkLicenseValidity($verificationURL, $clientIP);
}

// Lisansın geçerliliğine göre sayfayı yükle
if ($validLicense) {
} else {
    // Lisans geçersizse, harici sunucudan hata sayfasını al ve ekrana bas
    $errorPage = file_get_contents("$protocol://$host/licence/invalid");
    if ($errorPage === false) {
        die("Hata sayfası alınamadı.");
    }
    echo $errorPage;
    exit;
}
?>
